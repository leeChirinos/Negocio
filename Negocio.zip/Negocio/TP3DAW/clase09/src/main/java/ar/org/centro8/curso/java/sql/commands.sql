use negocio;
show tables;
select * from clientes;