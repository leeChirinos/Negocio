package ar.org.centro8.curso.java.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ar.org.centro8.curso.java.data.services.ArticuloDataService;
import ar.org.centro8.curso.java.entities.Articulo;
import ar.org.centro8.curso.java.enums.Rubro;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("servicios/articulos/v1")
public class ArticuloController {
    @Autowired
    private ArticuloDataService ads;

    @GetMapping()
    public String info() {
        return "Servicio articulos Activo";
    }

    /*
     * @GetMapping("/sumar")
     * public String sumar(@RequestParam("nro1") int nro1,@RequestParam("nro2") int
     * nro2){
     * int resultado=nro1+nro2;
     * return resultado+"";
     * }
     */

    /*
     * Método alta:
     * url: /alta
     * Descripción: ..................
     * Parámetros de entrada:
     * Método: POST
     * String descripcion
     * String rubro LACTEOS, PANADERIA, LIMPIEZA, PERSONAL, FIAMBRES, CARNICERIA,
     * BEBIDAS
     * String costo
     * String precio
     * String stock
     * String stock_minimo
     * String stock_maximo
     * Párametro de salida: int id Id generado por la base.
     */

    /**
     * @param descripcion
     * @param rubro
     * @param costo
     * @param precio
     * @param stock
     * @param stock_minimo
     * @param stock_maximo
     * @return
     */
    @PostMapping("/alta")
    public String save(
            @RequestParam("descripcion") String descripcion,
            @RequestParam("rubro") String rubro,
            @RequestParam("costo") double costo,
            @RequestParam("precio") double precio,
            @RequestParam("stock") Integer stock,
            @RequestParam("stock_minimo") Integer stock_minimo,
            @RequestParam("stock_maximo") Integer stock_maximo

    ) {
        try {
            Articulo articulo = new Articulo(
                    descripcion, // descripcion,
                    Rubro.valueOf(rubro), // rubro,
                    costo, // costo,
                    precio, // precio,
                    stock, // stock,
                    stock_minimo, // stock_minimo,
                    stock_maximo // stock_maximo
            );

            ads.save(articulo);

            return articulo.getId() + "";
        } catch (Exception e) {
            return "0";
        }
    }

    @PostMapping(value = "/baja")
    public String baja(@RequestParam("id") int id) {
        try {
            ads.remove(id);
            return "true";
        } catch (Exception e) {
            return "false";
        }
    }

    @GetMapping(value = "/all")
    public List<Articulo> getAll() {
        return ads.getAll();
    }

    @GetMapping(value = "/byId")
    public Articulo getById(int id) {
        return ads.getById(id);
    }

    /**
     * @param descripcion
     * @return
     */
    @GetMapping(value = "/LikeDescripcion")
    public List <Articulo> getLikeDescripcion(String descripcion) {
        return ads.getLikeDescripcion(descripcion);
    }

}
